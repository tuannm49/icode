/**
 * View Models used by Spring MVC REST controllers.
 */
package com.vnpt.egov.core.web.rest.vm;
