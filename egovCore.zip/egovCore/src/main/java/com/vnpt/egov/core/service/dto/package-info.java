/**
 * Data Transfer Objects.
 */
package com.vnpt.egov.core.service.dto;
