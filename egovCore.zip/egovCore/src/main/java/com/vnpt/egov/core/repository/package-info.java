/**
 * Spring Data JPA repositories.
 */
package com.vnpt.egov.core.repository;
