/**
 * Spring Security configuration.
 */
package com.vnpt.egov.core.security;
