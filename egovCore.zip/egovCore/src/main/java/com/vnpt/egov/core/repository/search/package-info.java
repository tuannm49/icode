/**
 * Spring Data Elasticsearch repositories.
 */
package com.vnpt.egov.core.repository.search;
