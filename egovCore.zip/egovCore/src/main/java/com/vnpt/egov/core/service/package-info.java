/**
 * Service layer beans.
 */
package com.vnpt.egov.core.service;
