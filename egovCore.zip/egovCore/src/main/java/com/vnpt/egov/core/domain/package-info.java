/**
 * JPA domain objects.
 */
package com.vnpt.egov.core.domain;
