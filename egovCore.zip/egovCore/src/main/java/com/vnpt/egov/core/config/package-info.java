/**
 * Spring Framework configuration files.
 */
package com.vnpt.egov.core.config;
